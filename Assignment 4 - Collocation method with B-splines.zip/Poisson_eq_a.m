%% a) A uniform charge distribution inside a sphere with radius R

r = 0:0.01:10; % Distance from the center of sphere
R = 1; % Outer radius
Q = 10; % Total charge

kord = 4; % Cubic splines
delta = 0.01; % Distance from the radius of the sphere to place additional knot points to capture the discontinuity in the second derivative
tknot = [repmat(r(1),1,kord), 0.3 0.5 0.6 0.7 R-delta R R+delta 1.2 1.5 2 3 5 7 8 9 repmat(r(end),1,kord)]; % Knot points
% tknot values must be included in r vector!

[Bavx,dBavx,dB2avx] = bsplgen(r,tknot,kord); % Generate the B-splines on the given grid and knot points
r = r'; % Transpose in order to work with column vectors
tknot = tknot';


%% Matrix and free term definition
% Assume 4*pi*eps_0 == 1

% Boundary conditions
alfa = 0; % Boundary condition at the center of the sphere; phi(0) == 0 
beta = Q; % Boundary condition at the end of the domain, much larger than the radius R;  phi(r>R) == Q/(4*pi*eps_0)

B = -tknot(kord:(end-kord+1)).*4*pi.*rho_a(tknot(kord:(end-kord+1)),R,Q); % Right hand side of system of equations
B = [B; alfa; beta]; % Augment with the boundary conditions. alfa = phi(0)

% Matrix 
no_Bspl = length(tknot) - kord; % Total number of B-splines
A = zeros(no_Bspl,no_Bspl); % Pre-allocate the full matrix to be solved

% Assign the matrix block corresponding to the physical points
toler = 1e-8*ones(length(r),1); % A vector of tolerances
for ii  = 1:(no_Bspl-2)
    A(ii,ii)   = dB2avx(abs(r - tknot(ii+kord-1)) < toler , ii);
    A(ii,ii+1) = dB2avx(abs(r - tknot(ii+kord-1)) < toler, ii+1);
    A(ii,ii+2) = dB2avx(abs(r - tknot(ii+kord-1)) < toler, ii+2);
end

A(end-1,1) = Bavx(abs(r - tknot(kord)) < toler,1); % The left boundary condition implementation, the first physical point 
A(end-1,2) = Bavx(abs(r - tknot(kord)) < toler,2); 
A(end-1,3) = Bavx(abs(r - tknot(kord)) < toler,3);

A(end,end-2) = Bavx(abs(r - tknot(end-kord+1)) < toler,end-2); % The eq. corresponding to the right boundary condition, in the last physical point
A(end,end-1) = Bavx(abs(r - tknot(end-kord+1)) < toler,end-1); 
A(end,end  ) = Bavx(abs(r - tknot(end-kord+1)) < toler,end);


%% Solve the system
cn = A\B; % The unknowns are all the coefficients c_n for the B-splines

phi = 0;
for ii = 1:length(cn)
    phi = phi + cn(ii)*Bavx(:,ii);
end

Vnum = phi./r;
Vexact = Vexact_a(r,R,Q);


%% Plot the results
figure
plot(r,Vnum,'Linewidth',1.2)
hold on
plot(r,Vexact,'--','Linewidth',1.2)
hold off
xlabel('r [arb. units]')
ylabel('V(r) [arb. units]') 
xline(R,':',{['R = ',num2str(R)]});
legend('Numerical','Analytical')

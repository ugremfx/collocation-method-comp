%% b) A uniform charge distribution inside a spherical shell,

r = 0:0.001:6; % Distance from the center of sphere
R1 = 1.98; % Inner radius
R2 = 2.02; % Outer radius
Q = 1; % Total charge

kord = 4; % Cubic splines
delta = 0.001; % A distance to place additional knot points to capture the discontinuity in the second derivative
%tknot = [repmat(r(1),1,kord), 0.001, 0.002, 0.3 0.5 0.6 0.7 0.8 0.9 0.93 R1-4*delta R1-3*delta R1-2*delta R1-delta R1 R1+delta R1+2*delta R1+3*delta R1+4*delta (R1+R2)/2 R2-4*delta R2-3*delta R2-2*delta R2-1*delta R2 R2+delta R2+2*delta R2+3*delta 1.1 1.2 1.4 1.5 2 3 5 5.99 5.999 repmat(r(end),1,kord)]; % Knot points
% tknot values must be included in r vector to obtain exact B-spline values in the knot positions!

tknot = [repmat(r(1),1,kord) 0.1:0.01:(R1-0.3) (R1-0.1):0.001:(R2+0.1) (R2+0.3):0.01:5.9 repmat(r(end),1,kord)];
if ~issorted(tknot)
    fprintf('Knot points are not sorted!\n')
return
end

[Bavx,dBavx,dB2avx] = bsplgen(r,tknot,kord); % Generate the B-splines on the given grid and knot points
r = r'; % Transpose in order to work with column vectors
tknot = tknot';


%% Matrix and free term definition
% Assume 4*pi*eps_0 == 1

% Boundary conditions
alfa = 0; % Boundary condition at the center of the sphere; phi(0) == 0 
beta = Q; % Boundary condition at the end of the domain, much larger than the radius R;  phi(r>R) == Q/(4*pi*eps_0)

B = -tknot(kord:(end-kord+1)).*4*pi.*rho_b(tknot(kord:(end-kord+1)),R1,R2,Q); % Right hand side of system of equations
B = [B; alfa; beta]; % Augment with the boundary conditions. alfa = phi(0)

% Matrix 
no_Bspl = length(tknot) - kord; % Total number of B-splines
A = zeros(no_Bspl,no_Bspl); % Pre-allocate the full matrix to be solved

% Assign the matrix block corresponding to the physical points
toler = 1e-8*ones(length(r),1); % A vector of tolerances
for ii  = 1:(no_Bspl-2)
    A(ii,ii)   = dB2avx(abs(r - tknot(ii+kord-1)) < toler , ii);
    A(ii,ii+1) = dB2avx(abs(r - tknot(ii+kord-1)) < toler, ii+1);
    A(ii,ii+2) = dB2avx(abs(r - tknot(ii+kord-1)) < toler, ii+2);
end

A(end-1,1) = Bavx(abs(r - tknot(kord)) < toler,1); % The left boundary condition implementation, the first physical point 
A(end-1,2) = Bavx(abs(r - tknot(kord)) < toler,2); 
A(end-1,3) = Bavx(abs(r - tknot(kord)) < toler,3);

A(end,end-2) = Bavx(abs(r - tknot(end-kord+1)) < toler,end-2); % The eq. corresponding to the right boundary condition, in the last physical point
A(end,end-1) = Bavx(abs(r - tknot(end-kord+1)) < toler,end-1); 
A(end,end  ) = Bavx(abs(r - tknot(end-kord+1)) < toler,end);



%% Solve the system
cn = A\B; % The unknowns are all the coefficients c_n for the B-splines

phi = 0; % Initialize
for ii = 1:length(cn)
    phi = phi + cn(ii)*Bavx(:,ii); % Assemble the solution based on B-splines and their coefficients
end


Vnum = phi./r; % Divide with r to obtain the potential
Vexact = Vexact_b(r,R1,R2,Q); % Get the analytical solution


%% Plot the results
figure
plot(r,Vnum,'Linewidth',1.2)
hold on
plot(r,Vexact,'--','Linewidth',1.2)
hold off
xlabel('r [arb. units]')
ylabel('V(r) [arb. units]') 
xl = xline((R1+R2)/2,':',{['Thin shell radius R = ',num2str((R1+R2)/2)]});
xl.LabelVerticalAlignment = 'bottom';
legend('Numerical','Analytical')

function [Bavx,dBavx,dB2avx] = bsplgen(xintervall,tknot,kord)
% Evaluates the splines, their first derivative and their second derivative
% on the "xintervall", given the order "kord" of the splines and the
% positions of the knots "tknot"



istart=1;
islut=length(tknot)-kord;


punkter = length(xintervall);
Bavx=zeros(punkter,islut);
dBavx = zeros(punkter,islut);
dB2avx = zeros(punkter,islut);

xnr=0;

for x = xintervall
    B = zeros(length(tknot),kord);
    xnr=xnr+1;
    for k=1:kord
        for i=istart:islut
            if k==1
                if tknot(i)< x && x < tknot(i+1)
                    B(i,1)=1;
                elseif tknot(i) == x && x < tknot(i+1)
                    B(i,1)=1;
                else
                    B(i,1)=0;
                end
            elseif k>1
                if i < kord-k+1
                    B(i,k)=0;
                elseif B(i,k-1)==0 && tknot(i+k-1)-tknot(i)==0
                    if B(i+1,k-1) == 0
                        B(i,k) =0;
                    else
                        B(i,k)=(tknot(i+k)-x)/(tknot(i+k)-tknot(i+1))*B(i+1,k-1);
                        if k==kord
                            dBavx(xnr,i) = (k-1)*( 0 - B(i+1,k-1)/(tknot(i+k)-tknot(i+1)));
                        end
                    end
                elseif  B(i+1,k-1)==0 && tknot(i+k)-tknot(i+1)==0
                    B(i,k)=(x-tknot(i))/(tknot(i+k-1)-tknot(i))* ...
                        B(i,k-1);
                    if k==kord
                        dBavx(xnr,i) = (k-1)*(B(i,k-1)/(tknot(i+k-1)-tknot(i))-0);
                    end
                else
                    B(i,k)=(x-tknot(i))/(tknot(i+k-1)-tknot(i))*B(i,k-1)+...
                        (tknot(i+k)-x)/(tknot(i+k)-tknot(i+1))*B(i+1,k-1);
                    if k==kord
                        dBavx(xnr,i) = (k-1)*(B(i,k-1)/(tknot(i+k-1)-tknot(i))-...
                            B(i+1,k-1)/(tknot(i+k)-tknot(i+1)));
                    end
                end
                if k==kord
                    if B(i,k-2)~=0
                        dB2avx(xnr,i)=(k-1)*(k-2)*B(i,k-2)/((tknot(i+k-1)-tknot(i))*(tknot(i+k-2)-tknot(i)));
                    end
                    if B(i+1,k-2)~=0
                        dB2avx(xnr,i)=dB2avx(xnr,i)-(k-1)*(k-2)*(...
                            B(i+1,k-2)/((tknot(i+k-1)-tknot(i))*(tknot(i+k-1)-tknot(i+1)))+...
                            B(i+1,k-2)/((tknot(i+k)-tknot(i+1))*(tknot(i+k-1)-tknot(i+1))));
                    end
                    if B(i+2,k-2)~=0
                        dB2avx(xnr,i)=dB2avx(xnr,i)+(k-1)*(k-2)*B(i+2,k-2)/((tknot(i+k)-tknot(i+1))*(tknot(i+k)-tknot(i+2)));
                    end
                end
            end
        end
        
    end
    
    for indexi=istart:islut
        
        if  (xnr == length(xintervall) && indexi ==islut)
            Bavx(xnr,indexi)= 1;
            dBavx(xnr,indexi) = (kord-1)/(tknot(length(tknot))-tknot(islut));
            dB2avx(xnr,indexi) =(kord-1)*(kord-2)/((tknot(length(tknot))-tknot(islut))*(tknot(length(tknot)-1)-tknot(islut)));
        elseif (xnr == length(xintervall) && indexi ==islut-1 )
            dBavx(xnr,indexi) = -(kord-1)/(tknot(length(tknot))-tknot(islut));
            dB2avx(xnr,indexi) =-(kord-1)*(kord-2)/((tknot(length(tknot))-tknot(islut))*(tknot(length(tknot)-1)-tknot(islut)))...
                -(kord-1)*(kord-2)/((tknot(length(tknot))-tknot(islut-1))*(tknot(length(tknot)-1)-tknot(islut)));
        elseif (xnr == length(xintervall) && indexi ==islut-2 )
            dB2avx(xnr,indexi) =(kord-1)*(kord-2)/((tknot(length(tknot))-tknot(islut-1))*(tknot(length(tknot)-1)-tknot(islut)));
        else
            
            Bavx(xnr,indexi)=B(indexi,kord);
        end
    end
    
end

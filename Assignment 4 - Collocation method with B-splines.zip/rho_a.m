function rho = rho_a(r,R,Q)
% Case a). A uniform charge distribution inside a sphere with radius R

V = 4*pi/3*R^3; % Volume of sphere
rho_0 = Q/V; % Constant uniform charge distribution inside the sphere 0<=r<=R

rho = zeros(length(r),1); % Initialization
for ii = 1:length(r)
    if r(ii) <= R
        rho(ii) = rho_0;
    else
        rho(ii) = 0;
    end
end

end
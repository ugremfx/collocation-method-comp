function rho = rho_b(r,R1,R2,Q)
% Case b). A uniform charge distribution inside a spherical shell.

V = 4*pi/3*(R2^3-R1^3); % Volume of shell 
rho_0 = Q/V; % Constant uniform charge distribution inside the sphere shell R1<=r<=R2

rho = zeros(length(r),1); % Initialization
for ii = 1:length(r)
    if r(ii) < R1
        rho(ii) = 0;
    elseif R1 <= r(ii) && r(ii) <= R2
        rho(ii) = rho_0;
    else
        rho(ii) = 0;
    end
end

end
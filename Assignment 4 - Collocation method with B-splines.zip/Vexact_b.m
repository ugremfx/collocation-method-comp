function V = Vexact_b(r,R1,R2,Q)
% Case b). Analytical solution for a uniformly charged thin solid shell of
% radius R. In our case, we will make R = (R1+R2)/2
% Assumption: 4*pi*eps_0 == 0

R = (R1+R2)/2;
for ii = length(r):-1:1
    if r(ii)>R
        V(ii,1) = Q/r(ii);
    else
        V(ii,1) = Q/R;
    end
end


end


function V = Vexact_c(r)
%c) The electron charge density as given from the hydrogen ground state wave function
a = 1;
% Assume e/(4*pi*eps_0) = 1

C1 = 1; % Corresponds to alfa = 0
C2 = -1/r(end); % For beta = 0
%C2 = 0; % For beta = 1

V = (C1 + C2*r - 1 * exp(-2*r/a).*(1+r/a))./r;

end


function rho = rho_c(r)
% c) The electron charge density as given from the hydrogen ground state wave function

a = 1 ; % In fact, a == hbar^2/(m*k*e^2) Bohr radius
% Assume e/(4*pi*eps_0) = 1

psi = 1/sqrt(pi*a^3)*exp(-r/a);
rho = 4*pi*psi.^2;


end
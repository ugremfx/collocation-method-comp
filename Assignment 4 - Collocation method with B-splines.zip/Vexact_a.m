function [V] = Vexact_a(r,R,Q)
% Case a). Analytical solution for a uniformly charged solid sphere of radius R
% Assumption: 4*pi*eps_0 == 0

for ii = length(r):-1:1
    if r(ii)>R
        V(ii,1) = Q/r(ii);
    else
        V(ii,1) = Q/(2*R)*(3-r(ii)^2/R^2);
    end
end

end

